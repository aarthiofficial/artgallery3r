create table artist (
    id int primary key auto_increment,
    name varchar(255),
    genre varchar(255)
);

create table art (
    id int primary key auto_increment,
    title varchar(255),
    theme varchar(255),
    artistId int,
    foreign key(artistId) references artist(id)
);

create table gallery (
    id int primary key auto_increment,
    name varchar(255),
    location varchar(255),
);

create table artist_gallery (
    artistId int,
    galleryId int,
    primary key(artistId,galleryId),
    foreign key(artistId) references artist(id),
    foreign key(galleryId) references gallery(id)
);