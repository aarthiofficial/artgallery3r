// Do not modify the code in this file
package com.example.artgallery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArtGalleryApplication {
    public static void main(String[] args) {
        SpringApplication.run(ArtGalleryApplication.class, args);
    }
}