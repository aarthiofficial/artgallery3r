insert into artist (id,name,genre) values(1,'Leonardo da Vinci','Renaissance');
insert into artist (id,name,genre) values(2,'Vincent van Gogh','Post-Impressionism');
insert into artist (id,name,genre) values(3,'Pablo Picasso','Cubism');
insert into artist (id,name,genre) values(4,'Edward Hopper','American Modernism');

insert into art (id,title,theme,artistId) values(1,'The Flight Study','Studies of Bird Wings',1);
insert into art (id,title,theme,artistId) values(2,'Mona Lisa 2.0','Renaissance Portrait',1);
insert into art (id,title,theme,artistId) values(3,'Starry Countryside','Night Landscape',2);
insert into art (id,title,theme,artistId) values(4,'Sunflower Impressions','Floral',2);
insert into art (id,title,theme,artistId) values(5,'Cubist Self-Portrait','Abstract Portrait',3);
insert into art (id,title,theme,artistId) values(6,'Barcelona Abstracted','City Landscape',3);
insert into art (id,title,theme,artistId) values(7,'Downtown Solitude','Urban Scene',4);
insert into art (id,title,theme,artistId) values(8,'Night Cafe Redux','Modernist Interior',4);

insert into gallery (id,name,location) values(1,'Louvre Museum','Paris');
insert into gallery (id,name,location) values(2,'Van Gogh Museum','Amsterdam');
insert into gallery (id,name,location) values(3,'Museo Picasso','Barcelona');
insert into gallery (id,name,location) values(4,'Whitney Museum of American Art','New York');

insert into artist_gallery (artistId,galleryId) values(1,1);
insert into artist_gallery (artistId,galleryId) values(1,2);
insert into artist_gallery (artistId,galleryId) values(2,2);
insert into artist_gallery (artistId,galleryId) values(3,3);
insert into artist_gallery (artistId,galleryId) values(3,4);
insert into artist_gallery (artistId,galleryId) values(4,4);